<?php

namespace YouTube\Exception;

class VideoPlayerNotFoundException extends YouTubeException
{

}