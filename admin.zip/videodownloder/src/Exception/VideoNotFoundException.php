<?php

namespace YouTube\Exception;

class VideoNotFoundException extends YouTubeException
{

}