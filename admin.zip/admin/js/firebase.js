const firebaseConfig = {
  apiKey: "AIzaSyCo__uG3NeRWzbqaEZRcZdhj6PUyimuyfk",
  authDomain: "video-downloader-c928d.firebaseapp.com",
  projectId: "video-downloader-c928d",
  storageBucket: "video-downloader-c928d.appspot.com",
  messagingSenderId: "58306925928",
  appId: "1:58306925928:web:be8f316b9ebc12d1cb72dd",
  measurementId: "G-WKJWEKXT27",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
