// GET and SHOW youtube playlist
const getYoutubeMultipleVideosData = async (playlistUrl) => {
  try {
    $("#overlay").css("display", "flex");
    const playlistIdVideos = await axios.get(
      `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId=${playlistUrl}&key=AIzaSyBm3nGWzJOZr8QIU0NDQzoGGKi-FzmobTg`
    );

    const videosIds = getPlaylistVideosIds(playlistIdVideos.data.items);
    youtubeVideosIds = videosIds;

    // get single video from api
    for (let j = 0; j < videosIds.length; j++) {
      const videoUrl = `https://www.youtube.com/watch?v=${videosIds[j]}`;

      $("#playlistvideo").html("");
      $("#result").css("display", "none");

      $.get(
        "video_info.php",
        {
          url: videoUrl,
        },
        function (objdata) {
          myStopFunction();
          const base = getYoutubeVideoFormats(objdata, videoUrl);

          youtubeVideos.push({ id: j, ...base });
          $("#overlay").css("display", "none");
          $("#playlist").css("display", "inherit");
          showPlaylistVideo(j, base, null); // (index, data, video quality)
          if (!gettingQualitiesCalled) {
            gettingQualitiesCalled = true;
            getvideoQualites(base.formats);
          }
        }
      );
    }
  } catch (error) {
    alert(error.message);
  }
};

/* 
   it sorts the playlist response
*/
$("#sortbutton").click(async () => {
  $("#playlistvideo").html("");
  youtubeVideos = youtubeVideos.sort((a, b) => a.id - b.id);
  for (let i = 0; i < youtubeVideos.length; i++) {
    showPlaylistVideo(i, null, null);
  }
});

/* 
   it display playlist response
*/
const showPlaylistVideo = (i, base = null, videoquality = null) => {
  if (!base) {
    base = youtubeVideos[i];
  }

  $("#playlistvideo").append(`
    <tr>
    <td data-label="#">
       ${i + 1}
    </td>
    <td data-label="Image">
    <img src="https://i.ytimg.com/vi/${
      youtubeVideosIds[i]
    }/default.jpg" width="100" height="50" />
    </td>
    <td data-label="Title"> ${base.title}</td>
    <td data-label="Download">
       ${
         base.formats
           ? ` <a
             href="${getPlaylistVideoUrl(base.formats, videoquality)}"
             rel="noreferrer"
             target="_blank"
             class="btn"
             data-quality="720"
             data-type="mp4"
           >
             <span>
               <i class="fa fa-download"></i>
             </span>
             <span class="download-label"> Download </span>
           </a>`
           : `<span class="error-message">This video has been blocked on copyright grounds</span>`
       } 
    </td>
    <td data-label="Force Download">
    ${
      base.formats
        ? `
    <a href="download.php?url=${encodeURIComponent(
      btoa(getPlaylistVideoUrl(base.formats, videoquality))
    )}&type=All_Video_Downloader_Youtube_${getQoute(
            base.title
          )}.mp4" rel="noreferrer" target="_blank" class="btn"
         data-quality="720" data-type="mp4">
         <span>
         <i class="fas fa-cloud-download-alt"></i>
         </span>
         <span class="download-label"> Force Download </span>
      </a>
    </td>
    `
        : `<span class="error-message">This video has been blocked on copyright grounds</span>`
    } 
    </td>
  </tr>`);
};

/* 
    Playlist videos ids from the response we get
*/
const getPlaylistVideosIds = (res) => {
  const ids = [];
  for (let i = 0; i < res.length; i++) {
    ids.push(res[i].snippet.resourceId.videoId);
  }
  return ids;
};

// Display Specific Quality Videos
$("select").change(function () {
  var selectedQuality = $(this).val();
  $("#playlistvideo").html("");
  for (let i = 0; i < youtubeVideos.length; i++) {
    showPlaylistVideo(i, null, selectedQuality);
  }
});

// Get Video Qualities
const getvideoQualites = (videos) => {
  for (let i = 0; i < videos.length; i++) {
    if (videos[i].acodec !== "none" && videos[i].vcodec !== "none") {
      $("#videoqualities").append(
        `<option value="${videos[i].quality}" onclick="displaySpecificQualityVideos(${videos[i].quality})"> ${videos[i].quality}</option>`
      );
    }
  }
};

/* 
   # this retrieves all the videos formats
   # it also separates the videos and audios and retrieve it
*/
const getYoutubeVideoFormats = (response, url) => {
  const videos = response.links[0];
  const formats = [];
  for (let i = 0; i < videos.length; i++) {
    const keyCode = videos[i].itag;
    const urlInfo = videoTags.find(
      (tag) => tag.tagId.toString() === keyCode.toString()
    );

    const v = {
      url: videos[i].url,
      filesize: videos[i].contentLength ? parseInt(videos[i].contentLength) : 0,
      quality: videos[i].qualityLabel,
      acodec: typeof urlInfo !== "undefined" && urlInfo.audio ? "yes" : "none",
      vcodec: typeof urlInfo !== "undefined" && urlInfo.video ? "yes" : "none",
      ext: typeof urlInfo !== "undefined" && urlInfo.video ? "mp4" : "mp3",
      protocol: "https",
    };

    formats.push(v);
  }

  const id = youtube_parser(url);

  const title = response.title;
  const object1 = {
    title: typeof title === "undefined" ? "Title of the video" : title,
    source: "youtube",
    thumbnail: `https://i.ytimg.com/vi/${id}/default.jpg`,
    duration: 40000,
    message: "success",
    formats: formats,
  };

  return object1;
};

/* 
   one video has many qualities e.g 360p, 720p etc
   it select one of its qulaity and retrieve it for each video
*/
const getPlaylistVideoUrl = (videos, videoquality) => {
  let url = videos[0].url;
  for (let i = 0; i < videos.length; i++) {
    if (videos[i].acodec !== "none" && videos[i].vcodec !== "none") {
      if (videoquality) {
        if (videos[i].quality.toString() === videoquality.toString()) {
          url = videos[i].url;
          return url;
        }
      } else {
        url = videos[i].url;
        return url;
      }
    }
  }
  return url;
};

/* 
   it handles single youtube video response
*/
const displayYoutubeData = (url) => {
  $("#thumbnail").html("");
  $("#videoDuration").html("");
  $("#title").html("");
  $("#result").css("display", "none");
  $("#overlay").css("display", "flex");
  $("#singleVideo").html("");
  $("#singleAudio").html("");
  $("#playlist").css("display", "none");

  $.get(
    "video_info.php",
    {
      url: url,
    },
    function (objdata) {
      myStopFunction();
      if (typeof objdata.links === "undefined") {
        $("#overlay").css("display", "none");
        $("#description").append("Invalid link");
        document.getElementsByClassName("popup")[0].classList.add("active");
      }

      if (objdata.links && objdata.links.length <= 0) {
        $("#overlay").css("display", "none");
        $("#description").append("No video found");
        document.getElementsByClassName("popup")[0].classList.add("active");
      }

      const response = getYoutubeVideoFormats(objdata, url);

      console.log(objdata);

      let result = response.formats;
      if (result) {
        result = getYtVideos(response);
      }
      if (result.totalAudios.length === 0 && result.totalVideos.length === 0) {
        $("#overlay").css("display", "none");
        $("#description").append("Not supported url");
        document.getElementsByClassName("popup")[0].classList.add("active");
        return;
      }

      $("#overlay").css("display", "none");
      $("#s-result").css("display", "none");
      $("#result").css("display", "inherit");
      $("#videosTab").css("display", "initial");
      $("#audiosTab").css("display", "initial");

      const data = response;
      if (result && result.totalVideos.length <= 0) {
        $("#videosTab").css("display", "none");
        document.getElementById("pills-profile-tab").classList.add("active");
        document.getElementById("pills-profile").classList.add("active");
        document.getElementById("pills-profile").classList.add("show");
        $("#pills-home-tab").removeClass("active");
        $("#pills-home").removeClass("show");
      }

      if (result && result.totalAudios.length <= 0) {
        $("#audiosTab").css("display", "none");
        document.getElementById("pills-home-tab").classList.add("active");
        document.getElementById("pills-home").classList.add("show");
        document.getElementById("pills-home").classList.add("active");
        $("#pills-profile-tab").removeClass("active");
        $("#pills-profile").removeClass("show");
      }

      if (result && result.totalVideos.length > 0) {
        $("#thumbnail").append(
          ` <video controlsList="nodownload" height="300px;" width="100%;" controls poster="${
            data.thumbnail
          }"
                  src="${getPreviewVideo(result.totalVideos)}"></video>`
        );
      } else if (result && result.totalAudios.length > 0) {
        $("#thumbnail").append(
          ` <video controlsList="nodownload" height="300px;" width="100%;" controls poster="${data.thumbnail}"
                  src="${result.totalAudios[0].url}"></video>`
        );
      } else if (data.thumbnail) {
        $("#thumbnail").append(
          `<img alt="thumbnail" class="thumnail-img" src="${data.thumbnail}" />`
        );
      } else {
        $("#thumbnail").append(
          `<img alt="thumbnail" class="thumnail-img" src="../assets/placeholder.jpg" />`
        );
      }

      $("#title").append(data.title);

      if (data.duration) {
        $("#videoDuration").append(
          new Date(parseInt(data.duration) * 1000).toISOString().substr(14, 5)
        );
      } else {
        $("#checkDuration").css("display", "none");
      }

      if (!result) {
        $("#response").css("display", "none");
        $("#copyright-response").css("display", "flex");
        return;
      }

      $("#response").css("display", "inherit");
      $("#copyright-response").css("display", "none");

      console.log(result);
      result.totalVideos.forEach((item) => {
        $("#singleVideo").append(`
                  <tr>
                  <td data-label="Extension">
                     ${
                       item.acodec === "none"
                         ? "<i class='fas fa-volume-mute'></i>"
                         : ""
                     }  ${item.ext} (${item.quality})
                  </td>
                  <td  data-label="File Size">
                      ${
                        item.filesize > 1024 * 1024
                          ? formatBytes(item.filesize)
                          : "NaN"
                      }
                  </td>
        
                  <td  data-label="Link">
                  <a href="${
                    item.url
                  }" rel="noreferrer" target="_blank" class="btn"
                      data-quality="720" data-type="mp4">
                      <span>
                          <i class="fa fa-download"></i>
                      </span>
                      <span class="download-label"> Download </span>
                  </a>
              </td>

              <td> 
              <iframe style="width:230px;height:40px;border:0;overflow:hidden;" scrolling="no" src="https://loader.to/api/button/?url=${url}&f=${getQuality(
          item.quality
        )}&color=64c896"></iframe>
              </td>
          <td  data-label="Mirror">
          <a href="download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader_${data.source}_${getQoute(
          data.title
        )}.mp4" rel="noreferrer" target="_blank" class="btn"
              >
               <span>
               <i class="fas fa-cloud-download-alt"></i>
               </span>
               <span class="download-label"> Force Download </span>
            </a>
          </td>
            
                 </tr>`);
      });
      result.totalAudios.forEach((item) => {
        $("#singleAudio").append(`
                    <tr>
                    <td  data-label="Extension">
                       ${item.ext}
                    </td>
                    <td  data-label="File Size">
                        ${
                          item.filesize > 1024 * 1024
                            ? formatBytes(item.filesize)
                            : "NaN"
                        }
                    </td>
                    <td  data-label="Link">
                  <a href="${
                    item.url
                  }" rel="noreferrer" target="_blank" class="btn"
                      data-quality="720" data-type="mp4">
                      <span>
                          <i class="fa fa-download"></i>
                      </span>
                      <span class="download-label"> Download </span>
                  </a>
              </td>

              <td> 
              <iframe style="width:230px;height:40px;border:0;overflow:hidden;" scrolling="no" src="https://loader.to/api/button/?url=${url}&f=mp3&color=64c896"></iframe>
              </td>
              
              <td  data-label="Mirror">
              <a href="download.php?url=${encodeURIComponent(
                btoa(item.url)
              )}&type=All_Video_Downloader_${data.source}_${getQoute(
          data.title
        )}.mp3" rel="noreferrer" target="_blank" class="btn"
                 data-quality="720" data-type="mp4">
                 <span>
                 <i class="fas fa-cloud-download-alt"></i>
                 </span>
                 <span class="download-label"> Force Download </span>
              </a>
            </td>
                </tr>`);
      });
    }
  );
};

/* 
   it check whether it is a youtube link or not
*/
function youtube_parser(url) {
  var regExp =
    /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
  var match = url.match(regExp);
  return match && match[7].length == 11 ? match[7] : false;
}

/* 
   it retrieves all the formats
*/

const getYtVideos = (response) => {
  let totalResponse = [...response.formats];
  const total_audios_and_videos = [];
  for (let i = 0; i < totalResponse.length; i++) {
    if (
      totalResponse[i].protocol === "https" ||
      totalResponse[i].protocol === "http"
    ) {
      total_audios_and_videos.push(totalResponse[i]);
    }
  }

  const totalAudios = [];
  const audiosResult = [...total_audios_and_videos];
  for (let i = 0; i < audiosResult.length; i++) {
    audioExtensions.forEach((item) => {
      if (item === audiosResult[i].ext) {
        if (
          audiosResult[i].vcodec === "none" &&
          audiosResult[i].acodec !== "none"
        ) {
          totalAudios.push(audiosResult[i]);
        }
      }
    });
  }

  const totalVideos = [];

  const vdieosResult = [...total_audios_and_videos];
  for (let i = 0; i < vdieosResult.length; i++) {
    videoExtensions.forEach((item) => {
      if (item === vdieosResult[i].ext) {
        if (vdieosResult[i].vcodec !== "none") {
          totalVideos.push(vdieosResult[i]);
        }
      }
    });
  }

  return { totalAudios, totalVideos };
};

function getQuality(text) {
  const splitedArr = text.split("p");
  if (splitedArr[0] == "2160") {
    splitedArr[0] = "4k";
  }
  if (splitedArr[0] == "4320") {
    splitedArr[0] = "8k";
  }
  return splitedArr[0];
}
