// Display Response
const displayData = (url) => {
//  var myUrl = "http://127.0.0.1:5000/api";
  var myUrl = "apidl.php";
  const code = sessionStorage.getItem("downloader-licence-code");



  $("#thumbnail").html("");
  $("#videoDuration").html("");
  $("#title").html("");
  $("#result").css("display", "none");
  $("#overlay").css("display", "flex");
  $("#singleVideo").html("");
  $("#singleAudio").html("");
  $("#playlist").css("display", "none");

  axios
    .get(myUrl+"?url="+url+"&code="+code)
  
    .then(function (response) {
      myStopFunction();



      if (
        typeof response.data.res_data !== "undefined" &&
        response.data.message !== "success"
      ) {
        $("#overlay").css("display", "none");
        $("#description").append(response.data.res_data);
        document.getElementsByClassName("popup")[0].classList.add("active");
        return;
      }

      
      var totalRes =  response.data.res_data
      // let totalRes = getDecryptedData(response.data.res_data);
      
      
    //   if (
    //     typeof totalRes.formats === "undefined"
    //   ){
          
    //          myStopFunction();
    //   $("#overlay").css("display", "none");
    //   $("#description").append(error.message);

    //   document.getElementsByClassName("popup")[0].classList.add("active");
          
          
    //   }
    console.log(totalRes.formats.length)
      
      var  result = totalRes.formats;
      if (result) {
        result = getVideos(totalRes);
      }
      
      if (result.totalAudios.length === 0 && result.totalVideos.length === 0) {
        $("#overlay").css("display", "none");
        $("#description").append("Not supported url");
        document.getElementsByClassName("popup")[0].classList.add("active");
        return;
      }

      $("#overlay").css("display", "none");
      $("#result").css("display", "inherit");
      $("#videosTab").css("display", "initial");
      $("#audiosTab").css("display", "initial");

      const data = totalRes;
      if (result && result.totalVideos.length <= 0) {
        $("#videosTab").css("display", "none");
        document.getElementById("pills-profile-tab").classList.add("active");
        document.getElementById("pills-profile").classList.add("active");
        document.getElementById("pills-profile").classList.add("show");
        $("#pills-home-tab").removeClass("active");
        $("#pills-home").removeClass("show");
      }

      if (result && result.totalAudios.length <= 0) {
        $("#audiosTab").css("display", "none");
        document.getElementById("pills-home-tab").classList.add("active");
        document.getElementById("pills-home").classList.add("show");
        document.getElementById("pills-home").classList.add("active");
        $("#pills-profile-tab").removeClass("active");
        $("#pills-profile").removeClass("show");
      }

      if (result && result.totalVideos.length > 0) {
        $("#thumbnail").append(
          ` <video controlsList="nodownload" height="300px;" width="100%;" controls poster="${
            data.thumbnail
          }"
            src="${getPreviewVideo(result.totalVideos)}"></video>`
        );
      } else if (result && result.totalAudios.length > 0) {
        $("#thumbnail").append(
          ` <video controlsList="nodownload" height="300px;" width="100%;" controls poster="${data.thumbnail}"
            src="${result.totalAudios[0].url}"></video>`
        );
      } else if (data.thumbnail) {
        $("#thumbnail").append(
          `<img alt="thumbnail" class="thumnail-img" src="${data.thumbnail}" />`
        );
      } else {
        $("#thumbnail").append(
          `<img alt="thumbnail" class="thumnail-img" src="../assets/placeholder.jpg" />`
        );
      }

      $("#title").append(data.title);

      if (data.duration) {
        $("#videoDuration").append(
          new Date(parseInt(data.duration) * 1000).toISOString().substr(14, 5)
        );
      } else {
        $("#checkDuration").css("display", "none");
      }

      if (!result) {
        $("#response").css("display", "none");
        $("#copyright-response").css("display", "flex");
        return;
      }

      $("#response").css("display", "inherit");
      $("#copyright-response").css("display", "none");

      result.totalVideos.forEach((item) => {
        $("#singleVideo").append(`
            <tr>
            <td data-label="Extension">
               ${
                 item.acodec === "none"
                   ? "<i class='fas fa-volume-mute'></i>"
                   : ""
               }  ${item.ext} ${
          typeof item.quality !== "undefined" ? `(${item.quality})` : ""
        }
            </td>
            <td  data-label="File Size">
                ${
                  item.filesize > 1024 * 1024
                    ? formatBytes(item.filesize)
                    : "NaN"
                }
            </td>
            <td  data-label="Link">
                <a href="${
                  item.url
                }" rel="noreferrer" target="_blank" class="btn"
                    data-quality="720" data-type="mp4">
                    <span>
                        <i class="fa fa-download"></i>
                    </span>
                    <span class="download-label"> Download </span>
                </a>
            </td>
            <td  data-label="Mirror">
            <a href="download.php?url=${encodeURIComponent(
              btoa(item.url)
            )}&type=All_Video_Downloader_${data.source}_${getQoute(
          data.title
        )}.mp4" rel="noreferrer" target="_blank" class="btn"
                >
                 <span>
                 <i class="fas fa-cloud-download-alt"></i>
                 </span>
                 <span class="download-label"> Force Download </span>
              </a>
            </td>
            </td>
        </tr>`);
      });
      result.totalAudios.forEach((item) => {
        $("#singleAudio").append(`
              <tr>
              <td  data-label="Extension">
                 ${item.ext}
              </td>
              <td  data-label="File Size">
                  ${
                    item.filesize > 1024 * 1024
                      ? formatBytes(item.filesize)
                      : "NaN"
                  }
              </td>
              <td  data-label="Link">
                  <a href="${
                    item.url
                  }" rel="noreferrer" target="_blank" class="btn"
                      data-quality="720" data-type="mp4">
                      <span>
                          <i class="fa fa-download"></i>
                      </span>
                      <span class="download-label"> Download </span>
                  </a>
              </td>
              
              <td  data-label="Mirror">
              <a href="download.php?url=${encodeURIComponent(
                btoa(item.url)
              )}&type=All_Video_Downloader_${data.source}_${getQoute(
          data.title
        )}.mp3" rel="noreferrer" target="_blank" class="btn"
                  >
                 <span>
                 <i class="fas fa-cloud-download-alt"></i>
                 </span>
                 <span class="download-label"> Force Download </span>
              </a>
            </td>
        
          </tr>`);
      });
    })
    .catch(function (error) {
      myStopFunction();
      $("#overlay").css("display", "none");
      $("#description").append(error.message);

      document.getElementsByClassName("popup")[0].classList.add("active");
    });
};

const getVideos = (totalRes) => {
  let totalResponse = [...totalRes.formats];
  const total_audios_and_videos = [];
  

  
  for (let i = 0; i < totalResponse.length; i++) {
    if (
      totalResponse[i].protocol === "https" ||
      totalResponse[i].protocol === "http"
    ) {


      total_audios_and_videos.push(totalResponse[i]);
          console.log("vvvvv "+totalResponse[i].protocol)
           console.log("vvvvv "+totalResponse[i].vcodec)
            console.log("vvvvv "+totalResponse[i].acodec)
    }
  }

  const totalAudios = [];
  const audiosResult = [...total_audios_and_videos];
  for (let i = 0; i < audiosResult.length; i++) {
    audioExtensions.forEach((item) => {
      if (item === audiosResult[i].ext) {
        // if (
        //   audiosResult[i].vcodec === "none" &&
        //   audiosResult[i].acodec !== "none"
        // ) {
  console.log("aaaaii "+audiosResult[i].protocol)             
          totalAudios.push(audiosResult[i]);
        // }
      }
    });
  }

  const totalVideos = [];

  const vdieosResult = [...total_audios_and_videos];
  for (let i = 0; i < vdieosResult.length; i++) {
    videoExtensions.forEach((item) => {
      if (item === vdieosResult[i].ext) {
        // if (vdieosResult[i].vcodec !== "none") {
          totalVideos.push(vdieosResult[i]);
          
  console.log("aaaaiivvf "+vdieosResult[i].protocol)          
        // }
      }
    });
  }


  console.log("aaaaii nnnnf "+totalAudios.length)  
  console.log("aaaaiivvf mmm  "+totalVideos.length)  
  
  
  return { totalAudios, totalVideos };
};

const getPreviewVideo = (videos) => {
  let videoUrl = videos[videos.length - 1].url;
  for (let i = 0; i < videos.length; i++) {
    if (
      videos[i].acodec !== "none" &&
      videos[i].vcodec !== "none" &&
      typeof videos[i].acodec !== "undefined" &&
      typeof videos[i].vcodec !== "undefined"
    ) {
      videoUrl = videos[i].url;
    }
  }
  return videoUrl;
};
