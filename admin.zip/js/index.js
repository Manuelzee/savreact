let gettingQualitiesCalled = false;
let apiKey = "dc242e05fba82b43c2bd2837007a59914392fa29d0385805208985b3";
let database = firebase.firestore();
var functionRef = null;

const videoExtensions = [
  "mp4",
  "(WithWatermark) mp4",
  "(WithoutWatermark) mp4",
  "mov",
  "avi",
  "wmv",
  "avchd",
  "flv",
  "f4v",
  "swf",
  "mkv",
  "webm",
  "mpeg-2",
  "unknown_video",
];

const audioExtensions = [
  "mp4a",
  "mp3",
  "vorbis",
  "aac",
  "opus",
  "flac",
  "m4a",
  "webm",
];
const videoTags = [
  { tagId: 5, audio: true, video: true },
  { tagId: 6, audio: true, video: true },
  { tagId: 17, audio: true, video: true },
  { tagId: 18, audio: true, video: true },
  { tagId: 22, audio: true, video: true },
  { tagId: 34, audio: true, video: true },
  { tagId: 35, audio: true, video: true },
  { tagId: 36, audio: true, video: true },
  { tagId: 37, audio: true, video: true },
  { tagId: 38, audio: true, video: true },
  { tagId: 43, audio: true, video: true },
  { tagId: 44, audio: true, video: true },
  { tagId: 45, audio: true, video: true },
  { tagId: 46, audio: true, video: true },
  { tagId: 82, audio: true, video: true },
  { tagId: 83, audio: true, video: true },
  { tagId: 84, audio: true, video: true },
  { tagId: 85, audio: true, video: true },
  { tagId: 92, audio: true, video: true },
  { tagId: 93, audio: true, video: true },
  { tagId: 94, audio: true, video: true },
  { tagId: 95, audio: true, video: true },
  { tagId: 96, audio: true, video: true },
  { tagId: 100, audio: true, video: true },
  { tagId: 101, audio: true, video: true },
  { tagId: 102, audio: true, video: true },
  { tagId: "mp3128", audio: true, video: false },
  { tagId: 132, audio: true, video: true },
  { tagId: 133, audio: false, video: true },
  { tagId: 134, audio: false, video: true },
  { tagId: 135, audio: false, video: true },
  { tagId: 136, audio: false, video: true },
  { tagId: 137, audio: false, video: true },
  { tagId: 138, audio: false, video: true },
  { tagId: 139, audio: true, video: false },
  { tagId: 140, audio: true, video: false },
  { tagId: 141, audio: true, video: false },
  { tagId: 151, audio: true, video: true },
  { tagId: 160, audio: false, video: true },
  { tagId: 167, audio: false, video: true },
  { tagId: 168, audio: false, video: true },
  { tagId: 169, audio: false, video: true },
  { tagId: 171, audio: true, video: false },
  { tagId: 218, audio: false, video: true },
  { tagId: 219, audio: false, video: true },
  { tagId: 242, audio: false, video: true },
  { tagId: 243, audio: false, video: true },
  { tagId: 244, audio: false, video: true },
  { tagId: 245, audio: false, video: true },
  { tagId: 246, audio: false, video: true },
  { tagId: 247, audio: false, video: true },
  { tagId: 248, audio: false, video: true },
  { tagId: 249, audio: true, video: false },
  { tagId: 250, audio: true, video: false },
  { tagId: 251, audio: true, video: false },
  { tagId: 264, audio: false, video: true },
  { tagId: 266, audio: false, video: true },
  { tagId: 271, audio: false, video: true },
  { tagId: 272, audio: false, video: true },
  { tagId: 278, audio: false, video: true },
  { tagId: 298, audio: false, video: true },
  { tagId: 299, audio: false, video: true },
  { tagId: 302, audio: false, video: true },
  { tagId: 303, audio: false, video: true },
  { tagId: 308, audio: false, video: true },
  { tagId: 313, audio: false, video: true },
  { tagId: 315, audio: false, video: true },
  { tagId: 330, audio: false, video: true },
  { tagId: 331, audio: false, video: true },
  { tagId: 332, audio: false, video: true },
  { tagId: 333, audio: false, video: true },
  { tagId: 334, audio: false, video: true },
  { tagId: 335, audio: false, video: true },
  { tagId: 336, audio: false, video: true },
  { tagId: 337, audio: false, video: true },
];

const checkMobileUser = () => {
  let check = false;
  (function (a) {
    if (
      /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(
        a
      ) ||
      /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(
        a.substr(0, 4)
      )
    )
      check = true;
  })(navigator.userAgent || navigator.vendor || window.opera);
  return check;
};

function getIpAddress(url) {
  return fetch(url).then((res) => res.text());
}

getIpAddress("https://ipapi.co/xml")
  .then(async (data) => {

    var parser, xmlDoc;
    parser = new DOMParser();
    console.log(data);
    xmlDoc = parser.parseFromString(data,"text/xml");


    const ip1 = xmlDoc.getElementsByTagName("ip")[0].childNodes[0].nodeValue;
    console.log(ip1);
    const country = xmlDoc.getElementsByTagName("country_name")[0].childNodes[0].nodeValue;
    const countryCode = xmlDoc.getElementsByTagName("country_code")[0].childNodes[0].nodeValue;
    const region =xmlDoc.getElementsByTagName("region")[0].childNodes[0].nodeValue;
    const long = xmlDoc.getElementsByTagName("longitude")[0].childNodes[0].nodeValue;
    const lat = xmlDoc.getElementsByTagName("latitude")[0].childNodes[0].nodeValue;
    const city = xmlDoc.getElementsByTagName("city")[0].childNodes[0].nodeValue;
    const timeStamp = Date.now();
    const useragent = navigator.userAgent;

    const ref = await database
      .collection("VisitingUsers")
      .where("ip", "==", ip1)
      .get();

    // if (typeof ref.docs === "undefined" || ref.docs.length === 0) {
    const dbRef = await database.collection("VisitingUsers").doc();
    await dbRef.set({
      ip1,
      country,
      timeStamp,
      countryCode,
      region,
      long,
      lat,
      useragent,
      city,
      id: dbRef.id,
      isFromMobile: checkMobileUser(),
    });
    // }
  })
  .catch((err) => {
    console.log(err);
    console.log("Saving User Info Error: ", err.message);
  });

// How to use use guide video
$(document).on("click", ".js-videoPoster", function (ev) {
  ev.preventDefault();
  var $poster = $(this);
  var $wrapper = $poster.closest(".js-videoWrapper");
  videoPlay($wrapper);
});

// play the targeted video (and hide the poster frame)
function videoPlay($wrapper) {
  var $iframe = $wrapper.find(".js-videoIframe");
  var src = $iframe.data("src");
  // hide poster
  $wrapper.addClass("videoWrapperActive");
  // add iframe src in, starting the video
  $iframe.attr("src", src);
}

// stop the targeted/all videos (and re-instate the poster frames)
function videoStop($wrapper) {
  // if we're stopping all videos on page
  if (!$wrapper) {
    var $wrapper = $(".js-videoWrapper");
    var $iframe = $(".js-videoIframe");
    // if we're stopping a particular video
  } else {
    var $iframe = $wrapper.find(".js-videoIframe");
  }
  // reveal poster
  $wrapper.removeClass("videoWrapperActive");
  // remove youtube link, stopping the video from playing in the background
  $iframe.attr("src", "");
}

let youtubeVideos = [];
let youtubeVideosIds = [];

function formatBytes(bytes, decimals = 2) {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
}

const getKey = () => {
  return Date.now() * Math.random() * 1000;
};

const getQoute = (title) => {
  let uTitle = title.replace(/(^"|"$)/g, "");
  uTitle = uTitle.replace(/\s/g, "");
  return uTitle.length > 11 ? uTitle.substring(0, 7) : uTitle;
};

// Click clipboard icon
$("#pastelink").click(async () => {
  if (navigator.clipboard) {
    let text = await navigator.clipboard.readText();

    document.getElementById("videoLink").value = text;
  } else {
    $("#description").append("Clipboard not supported");
    document.getElementsByClassName("popup")[0].classList.add("active");
  }
});

// Click download icon to search video
$("#downloadVideo").click(function () {
  showResponse();
});

// hit enter key of input box to search video
$("#videoLink").keypress("enterKey", function () {
  var keycode = event.keyCode ? event.keyCode : event.which;
  if (keycode.toString() === "13") {
    showResponse();
  }
});

const getYoutubeSingleVideoData = async (url) => {
  await displayYoutubeData(url);
};

const showResponse = async () => {
  let link = document.getElementById("videoLink").value;
  if (link.trim().length == 0) {
    $("#description").append("Ivalid Link");
    document.getElementsByClassName("popup")[0].classList.add("active");
    return;
  }

  // getIpAddress(`https://api.db-ip.com/v2/free/self`)
  //   .then(async (data) => {
  //     console.log("Complete Data: ", data);
  //     const ip = data.ip;
  //     const country = data.country_name;
  //     const countryCode = data.country_code;
  //     const region = data.region;
  //     const long = data.longitude;
  //     const lat = data.latitude;
  //     const city = data.city;
  //     const timeStamp = Date.now();
  //     const useragent = navigator.userAgent;
  //     const dbRef = await database.collection("DownloadUsers").doc();

  //     await dbRef.set({
  //       ip,
  //       country,
  //       city,
  //       timeStamp,
  //       countryCode,
  //       region,
  //       long,
  //       lat,
  //       useragent,
  //       id: dbRef.id,
  //       isFromMobile: checkMobileUser(),
  //       url: link,
  //     });
  //   })
  //   .catch((err) => {
  //     console.log("Saving User Info Error: ", err.message);
  //   });

  // apiCalledTimeOut();

  if (link.includes("youtube") || link.includes("youtu.be")) {
    let url = link;
    let playlistUrl = url.split("&list=");
    if (playlistUrl.length > 1) {
      playlistUrl = playlistUrl[1].split("&");
      playlistUrl = playlistUrl[0];
      await getYoutubeMultipleVideosData(playlistUrl);
    } else {
      await getYoutubeSingleVideoData(url);
    }
    return;
  }

  if (link.includes("snapchat.com")) {
    let url = link;
    await getSnapchatData(url);
    return;
  }

  if (link.includes("instagram.com")) {
    const confirm = window.confirm(
      "Instagram links will redirect instagram downloader page. Are you sure you weant to redirect?"
    );
    if (confirm) {
      window.location.href = `instagram.html?url=${link}`;
    } else {
      return;
    }
  }

  const updatedUrl = link.trim();

  await displayData(updatedUrl);
};

// Send email to admin
$("#sendemailbtn").click(function () {
  let sendemail = document.getElementById("emailinput").value;
  $("#sendemailbtn").attr(
    "href",
    `mailto:infusiblecoder@gmail.com?cc=${sendemail}?subject=Bug Reporting
  &body=Enter Your Message Here`
  );
});

// Dismiss the Dialog Box
$("#dismiss-popup-btn").click(function () {
  $("#description").html("");
  document.getElementsByClassName("popup")[0].classList.remove("active");
});

// Time out if there is no response in 3 minutes
const apiCalledTimeOut = () => {
  functionRef = setTimeout(() => {
    $("#overlay").css("display", "none");
    $("#description").append(
      "You internet connection is slow, Please refresh the page"
    );
    document.getElementsByClassName("popup")[0].classList.add("active");
  }, 180000);
};

// stop timeout func if there is a response
function myStopFunction() {
  clearTimeout(functionRef);
}


// function getDecryptedData(encryptedString) {
//   let cipher_algo = "AES-128-CTR";
//   let encrypt_key = new TextEncoder().encode("mdbuj8j9w9j@#$&");
//   let iv_length = 16;
//   let iv = encryptedString.slice(0, iv_length);
//   let encryptedText = encryptedString.slice(iv_length);
//   let algorithm = { name: "AES-CTR", counter: new Uint8Array(iv), length: 128 };
//   return crypto.subtle.decrypt(algorithm, encrypt_key, new Uint8Array(encryptedText))
//       .then(function (decryptedText) {
//           return new TextDecoder().decode(new Uint8Array(decryptedText));
//       });
// }


function getDecryptedData(encryptedString) {
  let cipher_algo = "AES-128-CTR";
  let key = new TextEncoder().encode("mdbuj8j9w9j@#$&");
  let iv_length = 16;
  let iv = encryptedString.slice(0, iv_length);
  let encryptedText = encryptedString.slice(iv_length);

  return crypto.subtle.importKey("raw", key, cipher_algo, false, ["encrypt", "decrypt"])
      .then(function (encrypt_key) {
          let algorithm = { name: "AES-CTR", counter: new Uint8Array(iv), length: 128 };
          return crypto.subtle.decrypt(algorithm, encrypt_key, new Uint8Array(encryptedText))
      })
      .then(function (decryptedText) {
          return new TextDecoder().decode(new Uint8Array(decryptedText));
        })
        .then(function (decryptedText) {
            return new TextDecoder().decode(new Uint8Array(decryptedText));
        })
        .catch(function (err) {
            console.log("Error during decryption: " + err.message);
        });
}
