let type = "story";
var url_string = window.location.href;
var url = new URL(url_string);
var reqUrl = url.searchParams.get("url");

if (reqUrl) {
  document.getElementById("privateLink").value = reqUrl;
  document.getElementById("callApiButton").click();
  // callApi();
}

function callApi() {
  const link = document.getElementById("privateLink").value;

  $("#response").html("");
  $("#overlay").css("display", "flex");

  if (link.trim().length <= 0) {
    $("#overlay").css("display", "none");
    $("#description").append("Invalid link");
    document.getElementsByClassName("popup")[0].classList.add("active");
    return;
  }

  let url = link.substr(0, link.lastIndexOf("/") + 1);
  url = `${url}?__a=1&__d=dis`;
  if (!link.includes("/stories/")) {
    type = "not-story";
    $("#analyzeContainer").css("display", "none");
    //let url = link.substr(0, link.lastIndexOf("/") + 1);
    // if (url.length > 50) {
    $("#overlay").css("display", "none");

    // $("#confirm-description").append(
    //   "This media is private, so you have to be logged in into the browser and the account should be followed by your account. If these condition have been met then press yes otherwise dismiss it!"
    // );
    if (url.length >= 65) {
      $("#confirm-description").append(
        "This media is private, so you have to be logged in into the browser and the account should be followed by your account. If these condition have been met then press yes otherwise dismiss it!"
      );
    } else {
      $("#confirm-description").append(
        "Alien text is going to appear on the other page copy it and paste it in the below text box!"
      );
    }

    document.getElementsByClassName("confirm-popup")[0].classList.add("active");
    return;
    // } else {
    //   var data = JSON.stringify({
    //     type: "we",
    //     link: url,
    //   });

    //   var config = {
    //     method: "post",
    //     url: "https://videodownloaderapinodejs.herokuapp.com/api/insta/v1",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //     data: data,
    //   };

    //   axios(config)
    //     .then(function (response) {
    //       console.log(response.data);
    //       $("#overlay").css("display", "none");
    //       showResponse(response.data);
    //     })
    //     .catch(function (error) {
    //       $("#overlay").css("display", "none");
    //       $("#description").append(error.message);
    //       document.getElementsByClassName("popup")[0].classList.add("active");
    //     });
    // }
  } else {
    type = "story";
    var data = JSON.stringify({
      type: "story",
      link: url,
    });

    var config = {
      method: "post",
      url: "https://videodownloaderapinodejs.herokuapp.com/api/insta/v1",
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    axios(config)
      .then(function (response) {
        $("#overlay").css("display", "none");
        $("#analyzeContainer").css("display", "initial");
        const url = response.data.url;
        console.log(url.toString());
        // window.open(url.toString(), "_blank");
        Object.assign(document.createElement("a"), {
          target: "_blank",
          href: url,
        }).click();
      })
      .catch(function (error) {
        $("#overlay").css("display", "none");
        $("#description").append(error.message);
        document.getElementsByClassName("popup")[0].classList.add("active");
      });
  }
}

function analyze() {
  let response1 = document.getElementById("response").value;

  if (response1.trim() === "") {
    $("#description").append(
      "Please paste the response which is open on the next tab!"
    );
    document.getElementsByClassName("popup")[0].classList.add("active");
    return;
  }
  response1 = JSON.parse(response1);
  if (type === "story") {
    const totalResponse = getStoryResponse(response1);
    showResponse(totalResponse);
  } else {
    if (typeof response1.items === "undefined") {
      const totalResponse = getAuthenticResponse(response1);
      showResponse(totalResponse);
    } else {
      const totalResponse = getPrivateVideoReponse(response1);
      showResponse(totalResponse);
    }
  }
}

// Dismiss the Dialog Box
$("#dismiss-popup-btn").click(function () {
  $("#description").html("");
  document.getElementsByClassName("popup")[0].classList.remove("active");
});

function showResponse1(items1) {
  $("#tableID").html("");
  $("#totalResponse").css("display", "inline-table");
  for (let i = 0; i < items1.length; i++) {
    const item = items1[i];

    $("#tableID").append(`
    <tr>
    <td>${item.type === 1 ? "Image" : "Video"}</td>
    <td><a href="${item.url}" target="_blank">Preview </a></td>
    <td><a href="${
      item.type === 1
        ? item.url
        : `download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader.mp4`
    }" target="_blank">Download </a></td>
  </tr>
    `);
  }
}

function showResponse(items1) {
  $("#tableID").html("");
  $("#totalResponse").css("display", "inline-table");
  for (let i = 0; i < items1.length; i++) {
    const item = items1[i];
    if (item.type === 1) {
      $("#tableID").append(`<div class="grid-item"> 
     
      <div class="insta-preview-resource">

      
      <img height="400" width="100%" src="streamthumb.php?t=i&amp;url=${encodeURIComponent(
        item.thumb
      )}"/>
      </div>

    <a style="padding:10px !important;" href="${
      item.type === 1
        ? `download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader.jpg`
        : `download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader.mp4`
    }" target="_blank" class="btn btn-insta-download"><i class="fa fa-download"></i> Download </a>
    </div>`);
    } else {
      $("#tableID").append(`<div class="grid-item"> 
     
      <div class="insta-preview-resource">

      <span class="iconoverlay"><div><i class="fa fa-play"></i> </div> </span>
      <img height="400" width="100%" src="streamthumb.php?t=i&amp;url=${encodeURIComponent(
        item.thumb
      )}"/>
      </div>

    <a style="padding:10px !important;" href="${
      item.type === 1
        ? `download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader.jpg`
        : `download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader.mp4`
    }" target="_blank" class="btn btn-insta-download"><i class="fa fa-download"></i> Download </a>
    </div>`);
    }

    //   $("#tableID").append(`
    //   <tr>`);
    //   if (item.type === 1) {
    //     $("#tableID").append(`
    //   <td>Image<br>
    //   <img height="400" src="streamthumb.php?t=i&amp;url=${encodeURIComponent(
    //     item.url
    //   )}"/><br>
    //   `);
    //   } else {
    //     $("#tableID").append(`
    //   <td>Video<br>
    //   <img height="400" src="streamthumb.php?t=i&amp;url=${encodeURIComponent(
    //     item.thumb
    //   )}"/><br>
    //   `);
    //   }

    //   $("#tableID").append(`
    //   <a href="${
    //     item.type === 1
    //       ? `download.php?url=${encodeURIComponent(
    //           btoa(item.url)
    //         )}&type=All_Video_Downloader.jpg`
    //       : `download.php?url=${encodeURIComponent(
    //           btoa(item.url)
    //         )}&type=All_Video_Downloader.mp4`
    //   }" target="_blank" class="btn"><i class="fa fa-download"></i> Download </a><br></td>
    // </tr>
    //   `);

    //   $("#tableID").append(`  </tr> `);
  }
}

function getPrivateVideoReponse(response1) {
  let totalResponse = [];

  const itemsData = response1.items[0];

  if (itemsData.media_type === 8) {
    for (let i = 0; i < itemsData.carousel_media.length; i++) {
      const carasoulData = itemsData.carousel_media[i];
      if (carasoulData.media_type === 2) {
        const carasoulItemUrl = carasoulData.video_versions[0].url;
        totalResponse.push({
          type: 2,
          url: carasoulItemUrl,
          thumb: carasoulData.image_versions2.candidates[0].url,
        });
      } else {
        const carasoulItemUrl = carasoulData.image_versions2.candidates[0].url;
        totalResponse.push({
          type: 1,
          url: carasoulItemUrl,
          thumb: carasoulData.image_versions2.candidates[0].url,
        });
      }
    }
  } else {
    if (itemsData.media_type === 2) {
      const carasoulItemUrl = itemsData.video_versions[0].url;
      totalResponse.push({
        type: 2,
        url: carasoulItemUrl,
        thumb: itemsData.image_versions2.candidates[0].url,
      });
    } else {
      const carasoulItemUrl = itemsData.image_versions2.candidates[0].url;
      totalResponse.push({
        type: 1,
        url: carasoulItemUrl,
        thumb: itemsData.image_versions2.candidates[0].url,
      });
    }
  }
  return totalResponse;
}

function getAuthenticResponse(response1) {

  let totalResponse = [];

  const itemsData = response1.graphql.shortcode_media;

  if (
    typeof itemsData.edge_sidecar_to_children !== "undefined" &&
    itemsData.edge_sidecar_to_children
  ) {
    for (let i = 0; i < itemsData.edge_sidecar_to_children.edges.length; i++) {
      const carasoulData = itemsData.edge_sidecar_to_children.edges[i];
      if (carasoulData.node.is_video) {
        const carasoulItemUrl = carasoulData.node.video_url;
        totalResponse.push({
          type: 2,
          url: carasoulItemUrl,
          thumb: carasoulData.node.display_url,
        });
      } else {
        const carasoulItemUrl =
          carasoulData.node.display_resources[
            carasoulData.node.display_resources.length - 1
          ].src;
        totalResponse.push({
          type: 1,
          url: carasoulItemUrl,
          thumb: carasoulData.node.display_url,
        });
      }
    }
  } else {
    if (itemsData.is_video) {
      const carasoulItemUrl = itemsData.video_url;
      totalResponse.push({
        type: 2,
        url: carasoulItemUrl,
        thumb: itemsData.display_url,
      });
    } else {
      const carasoulItemUrl =
        itemsData.display_resources[itemsData.display_resources.length - 1].src;
      totalResponse.push({
        type: 1,
        url: carasoulItemUrl,
        thumb: itemsData.display_url,
      });
    }
  }
  return totalResponse;
}

function getStoryResponse(response1) {
  const itemsData = response1.data.reels_media[0].items;

  const totalResponse = [];
  for (let j = 0; j < itemsData.length; j++) {
    const item = itemsData[j];
    if (item.is_video) {
      totalResponse.push({ type: 2, url: item.video_resources[0].src });
    } else {
      totalResponse.push({ type: 1, url: item.display_url });
    }
  }
  return totalResponse;
}

function clearLinkInput() {
  document.getElementById("privateLink").value = "";
}

function privateMediaHandler() {
  const link = document.getElementById("privateLink").value;
  let url = link.substr(0, link.lastIndexOf("/") + 1);
  url = `${url}?__a=1&__d=dis`;
  $("#overlay").css("display", "none");
  $("#analyzeContainer").css("display", "initial");
  window.open(url, "_blank");
  $("#confirm-description").html("");
  document
    .getElementsByClassName("confirm-popup")[0]
    .classList.remove("active");
}

// Dismiss the Dialog Box
$("#confirm-dismiss-popup-btn").click(function () {
  $("#confirm-description").html("");
  document
    .getElementsByClassName("confirm-popup")[0]
    .classList.remove("active");
});
