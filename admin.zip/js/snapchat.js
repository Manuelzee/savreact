const getSnapchatData = (url) => {
  $("#thumbnail").html("");
  $("#title").html("");
  $("#s-thumbnail").html("");
  $("#s-title").html("");
  $("#s-result").css("display", "none");
  $("#overlay").css("display", "flex");
  $("#s-singleVideo").html("");
  $("#s-singleImage").html("");

  $.get(
    "snapchat.php",
    {
      url: url,
    },
    function (objdata) {
      console.log(objdata);
      myStopFunction();
      if (typeof objdata.links === "undefined") {
        $("#overlay").css("display", "none");
        $("#description").append("Invalid link");
        document.getElementsByClassName("popup")[0].classList.add("active");
      }

      if (objdata.links && objdata.links.length <= 0) {
        $("#overlay").css("display", "none");
        $("#description").append("Not found");
        document.getElementsByClassName("popup")[0].classList.add("active");
        return;
      }

      const response = getSnapchatFormats(objdata, url);

      if (
        response.totalImages.length === 0 &&
        response.totalVideos.length === 0
      ) {
        $("#overlay").css("display", "none");
        $("#description").append("Not supported url");
        document.getElementsByClassName("popup")[0].classList.add("active");
        return;
      }

      $("#overlay").css("display", "none");
      $("#result").css("display", "none");
      $("#s-result").css("display", "inherit");
      $("#snapvideoTab").css("display", "initial");
      $("#snapimagessTab").css("display", "initial");

      const data = response;
      if (data && data.totalVideos.length <= 0) {
        $("#snapvideosTab").css("display", "none");
        document.getElementById("s-pills-profile-tab").classList.add("active");
        document.getElementById("s-pills-profile").classList.add("active");
        document.getElementById("s-pills-profile").classList.add("show");
        $("#s-pills-home-tab").removeClass("active");
        $("#s-pills-home").removeClass("show");
      }

      if (data && data.totalImages.length <= 0) {
        $("#audiosTab").css("display", "none");
        document.getElementById("s-pills-home-tab").classList.add("active");
        document.getElementById("s-pills-home").classList.add("show");
        document.getElementById("s-pills-home").classList.add("active");
        $("#s-pills-profile-tab").removeClass("active");
        $("#s-pills-profile").removeClass("show");
      }

      if (data && data.totalVideos.length > 0) {
        $("#s-thumbnail").append(
          ` <video controlsList="nodownload" height="300px;" width="100%;" controls poster="${objdata.thumb}"
                  src="${data.totalVideos[0].url}"></video>`
        );
      } else if (objdata.thumb) {
        $("#s-thumbnail").append(
          `<img alt="thumbnail" class="thumnail-img" src="${objdata.thumb}" />`
        );
      } else {
        $("#s-thumbnail").append(
          `<img alt="thumbnail" class="thumnail-img" src="../assets/placeholder.jpg" />`
        );
      }

      $("#s-title").append(objdata.title);

      data.totalVideos.forEach((item) => {
        $("#s-singleVideo").append(`
                  <tr>
                  <td data-label="Extension">
                     ${
                       item.acodec === "none"
                         ? "<i class='fas fa-volume-mute'></i>"
                         : ""
                     }  ${item.ext}
                  </td>
                  <td  data-label="File Size">
                      ${
                        item.filesize > 1024 * 1024
                          ? formatBytes(item.filesize)
                          : "NaN"
                      }
                  </td>

                  <td  data-label="Link">
                  <a href="${
                    item.url
                  }" rel="noreferrer" target="_blank" class="btn"
                      data-quality="720" data-type="mp4">
                      <span>
                          <i class="fa fa-download"></i>
                      </span>
                      <span class="download-label"> Download </span>
                  </a>
              </td>

             
          <td  data-label="Mirror">
          <a href="download.php?url=${encodeURIComponent(
            btoa(item.url)
          )}&type=All_Video_Downloader_${getQoute(
          objdata.title
        )}.mp4" rel="noreferrer" target="_blank" class="btn"
              >
               <span>
               <i class="fas fa-cloud-download-alt"></i>
               </span>
               <span class="download-label"> Force Download </span>
            </a>
          </td>
        </tr>`);
      });
      data.totalImages.forEach((item) => {
        $("#s-singleImage").append(`
                    <tr>
                    <td  data-label="Extension">
                       ${item.ext}
                    </td>
                    <td  data-label="File Size">
                        ${
                          item.filesize > 1024 * 1024
                            ? formatBytes(item.filesize)
                            : "NaN"
                        }
                    </td>
                    <td  data-label="Link">
                  <a href="${
                    item.url
                  }" rel="noreferrer" target="_blank" class="btn"
                      data-quality="720" data-type="mp4">
                      <span>
                          <i class="fa fa-download"></i>
                      </span>
                      <span class="download-label"> Download </span>
                  </a>
              </td>

           

              <td  data-label="Mirror">
              <a href="download.php?url=${encodeURIComponent(
                btoa(item.url)
              )}&type=All_Video_Downloader_${getQoute(
          objdata.title
        )}.jpg" rel="noreferrer" target="_blank" class="btn"
                 data-quality="720" data-type="mp4">
                 <span>
                 <i class="fas fa-cloud-download-alt"></i>
                 </span>
                 <span class="download-label"> Force Download </span>
              </a>
            </td>
                </tr>`);
      });
    }
  );
};

const getSnapchatFormats = (response) => {
  const snapformats = response.links;
  const totalVideos = [];
  const totalImages = [];
  for (let i = 0; i < snapformats.length; i++) {
    const item = snapformats[i];
    const v = {
      url: snapformats[i],
      acodec: "yes",
      vcode: "yes",
    };

    if (item.includes(".80") || item.includes(".111") || item.includes(".27")) {
      v.ext = "mp4";
      totalVideos.push(v);
    } else {
      v.ext = "jpg";
      totalImages.push(v);
    }
  }

  return { totalImages, totalVideos };
};
